from flask import Flask,render_template,request
import random
import pandas as pd
import os
'''
df = pd.read_json("AAPLbdc2518.json")
print(df.iloc[3])

columns=list(df)
print(columns)

for i in columns:
    print(df[i][2])

for i in df['Date']:
    if i=="2021-12-30":
        print("present")
'''
app = Flask(__name__)
'''
ROCK_ACTION=0
PAPER_ACTION=1
SCISSORS_ACTION=2
comp_num=random.randint(0,2)
print(comp_num)
'''

@app.route("/",methods=['GET','POST'])

def fun():
    df = pd.read_json("AAPLbdc2518.json")
    message=''
    if request.method=='POST':
        form=request.form
        user_guess=form['fname']
        #print(user_guess)
        cnt=0
        for i in range(len(df)):
            print(df.iloc[i][0].date())
            if str(df.iloc[i][0].date())==user_guess:
                print("Yes")
                Open=df.iloc[i][1]
                High=df.iloc[i][2]
                Low=df.iloc[i][3]
                Close=df.iloc[i][4]
                Plus=High-Open
                Minus=Open-Low
                if Plus>Minus:
                    message=" Strategy : Long  " + "  & Profit = " + str(Plus)
                    return render_template("game_over.html",message=message)
            
                else:
                    message=" Strategy : Short  " + "  & Profit = " + str(Plus)
                    return render_template("game_over.html",message=message)
                cnt=1
                break
              
            
        if cnt==0:
            print("Not present")
            
                
        
        
        #if comp_num==user_guess:
         #   message="It's tie"
          #  return render_template("game_over.html",message=message)
    
        
            
    return render_template("guess.html",message=message)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
    
